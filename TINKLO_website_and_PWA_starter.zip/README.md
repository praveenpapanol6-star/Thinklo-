# TINKLO Easy Gadgets — starter storefront + installable PWA

## Included
- Mobile-friendly product catalog and cart
- WhatsApp order handoff (no payment processing)
- PWA manifest and service worker for installable Android experience
- Sample product list/prices

## Before launch
1. In `app.js`, replace `91XXXXXXXXXX` with the verified WhatsApp number (digits only, country code included).
2. Replace sample product prices/descriptions and add your actual stock.
3. Add your official business email and return/shipping/privacy policies.
4. Deploy the folder to a host that serves HTTPS (e.g. GitHub Pages, Netlify, or your own domain).
5. On Android, open the HTTPS website in Chrome and choose **Install app** / **Add to Home screen**.

## Important
This is a front-end starter, not a production ecommerce backend. It does not securely store orders, manage inventory, authenticate an admin, or accept online payments. Those features require a backend/payment provider and proper setup. It is not an APK; it is an installable PWA.
